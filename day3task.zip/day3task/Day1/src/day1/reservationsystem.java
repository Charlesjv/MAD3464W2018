/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package day1;

/**
 *
 * @author Charles JV
 */
public class reservationsystem {
 int maxlimit;
 int[] seats = new int[30];

 reservationsystem(){
     this.maxlimit=0;
     for(int i=0;i<=10;i++){
         seats[i]=0;
         }}
 reservationsystem(int new_cap){
     this.maxlimit = new_cap;
 }
     public void assignSeatingCapacity(int cap){
         this.maxlimit=cap;
         for(int i=0;i<=cap;i++){
             seats[i]=0;
         }}
         
        public void assign_seating(int seatno){
         if(seatno > this.maxlimit)
         {System.out.println("Invalid choice");}
         
            
         else if(seats[seatno]==0){
                seats[seatno]=1;
                System.out.println("This seat has been booked for u");
                
         }
         else{
             System.out.println("This seat is already taken");
             
        }
         
     
     
 }
}
