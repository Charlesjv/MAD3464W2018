/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package day1;

import java.util.Scanner;

/**
 *
 * @author Charles JV
 */
public class flightreservation extends reservationsystem {
    
    int choice,i,j;
    flightreservation(){
         choice = 0;
    
     
    }
    
  public void make_a_reservation(){
      
          System.out.println("Enter your choice");
          System.out.println("Press 1 : Book a seat in smokers  \n Press 2: Book a seat in non smokers section \n");
          Scanner myinput = new Scanner(System.in);
        choice = myinput.nextInt();
        if(choice == 1)
        {
           smoking();
        }        
        else {
            if(choice == 2){
                nonsmoking();
            }    else{
System.out.println("Wrong choice\n");

        }
  }
  
  }
   
  
  public void smoking(){
       System.out.println("Enter the seat no:");
 Scanner input = new Scanner(System.in);
 int input1 = input.nextInt();
        
      for(i=input1;i<=5;i++){
          if(seats[i]==0){
              
          seats[i] = 1;
        break;
      }
          
          else if(seats[input1]==1)
          {System.out.println("Seat is already taken \n The next flight is in 3 hours\n");
         make_a_reservation();
        } 
      else  
      {System.out.println("\n");
       }
      }     
      System.out.println("Your seat has been booked\n");
   make_a_reservation();}
    public void nonsmoking(){
        System.out.println("Enter the seat no from 5 to 10:");
 Scanner input = new Scanner(System.in);  
    int input2 = input.nextInt();
    if(input2 >= 5 && input2 <= 10){
    for(j=input2;j<=5;j++) {
        
        if(seats[j]==0){
      seats[j]=1;
      
      break;
      }
        
        else if(seats[input2] == 1) {
          {System.out.println("Seat is already taken \n The next flight is in 3 hours\n");
        make_a_reservation();
        }}
        else{System.out.println("\n");
        }
        
    }
     System.out.println("Your seat has been booked\n");
    make_a_reservation();}
    else{ System.out.println("Please choose a seat from 5 to 10\n");
    make_a_reservation();}
}}