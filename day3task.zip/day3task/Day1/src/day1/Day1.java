/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package day1;

import java.util.Scanner;

/**
 *
 * @author Charles JV
 */
public class Day1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
//      reservationsystem obj = new reservationsystem();
//      
//     System.out.println("Enter the seating capacity");
//     Scanner noOfSeats = new Scanner(System.in);
//    int NoOfSeats =  noOfSeats.nextInt();
//     obj.assignSeatingCapacity(NoOfSeats);
//     
//     System.out.println("Enter the seat no.");
//     Scanner seatNo = new Scanner(System.in);
//     int SeatNO = seatNo.nextInt();
//     obj.assign_seating(SeatNO);
//     
     
      
      
       flightreservation obj1 = new flightreservation();
       obj1.make_a_reservation();
    }
    
}
