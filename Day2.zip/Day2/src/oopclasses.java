/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author macstudent
 */
import java.util.Scanner;
public class oopclasses {
   
   public static void main(String[] args)
   {
   Bank myBank = new Bank();
  
   System.out.println("Bank ID" + myBank.BankID);
   System.out.println("Bank Name:" +myBank.bankName);
   
   Bank yourBank = new Bank();
   
   yourBank.BankID = 1231;
   yourBank.bankName = "RBC";
   
    System.out.println("Bank ID" + yourBank.BankID);
   System.out.println("Bank Name:" +yourBank.bankName);
   
   
   yourBank.getBankName();
   
   yourBank.setBankName("Bank of Montreal");
   yourBank.getBankName();
   //-------------------------------------------//
   Scanner myInput = new Scanner(System.in);
   String name;
   System.out.println("Enter bank name:");
   name = myInput.nextLine();
   yourBank.setBankName(name);
   yourBank.getBankName();
   
   //====================================================
   Arithmetic operation1  = new Arithmetic();
   System.out.println("Addition of integer addition" + operation1.addition(10,20));
   System.out.println("Float addition of integer addition" + operation1.addition(10.20f,20.40f));
   System.out.println("Addition of integer addition" + operation1.addition(10,20,30));
   System.out.println("Multiplication of integer " + operation1.multiplication(10,20,30));
  Arithmetic.multiplication(10,20);
 
  Arithmetic.n2 = 40;
          System.out.println("Multiplication of integer " + Arithmetic.n1 + "" + Arithmetic.n2);
   
   }
   
  
   
   
}
