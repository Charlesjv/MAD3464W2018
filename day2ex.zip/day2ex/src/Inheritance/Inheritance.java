/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Inheritance;

/**
 *
 * @author macstudent
 */
public class Inheritance {
    
    public static void main(String[] args){
   
    Person one = new Person();
            one.displayData();
    
            Person sreejith = new Person("Sreejith","Thrivikraman",10);
            sreejith.displayData();
    Person sreejith2 = new Person(sreejith);
    sreejith2.displayData();
    //Employee e1 = new Employee(14.50);
    //e1.display();
    System.out.println("------------");
    Employee e2 = new Employee();
    e2.display();
    System.out.println("Lastname:" + e2.lastname);
    
    e2.firstname = 
            "JK";
    e2.lastname = "JK";
    e2.age = 10;
    e2.salary = 1000;
    e2.displayData();
    e2.display();
    
    Employee E3 = new Employee();
    E3.read();
    E3.display();
    }
   
}
