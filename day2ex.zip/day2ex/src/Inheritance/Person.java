/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Inheritance;


import java.util.Scanner;

/**
 *
 * @author macstudent
 */
public class Person {
    String firstname;
    String lastname;
    int age;
    //default constructor
    Person(){
        this.firstname = "Unknown";
        this.lastname = "Unknown";
        this.age = 33;
        
    }
    
    Person(String fNM,String lNM, int age){
    this.firstname = fNM;
    this.lastname = lNM;
    this.age = age;}
    Person(Person object){
        this.firstname = object.firstname;
        this.lastname = object.lastname;
        this.age = object.age;
        
    }
    
    void readdata(){
        Scanner input = new Scanner(System.in);
        System.out.println("Enter first name:");
        this.firstname = input.nextLine();
        System.out.println("Enter lastname:");
        this.lastname = input.nextLine();
        System.out.println("Enter age");
        this.age = input.nextInt();
    }     
        void displayData(){
        System.out.println("Firstname:" + this.firstname);
        System.out.println("Enter lastname:" + this.lastname);
         System.out.println("Enter age" + this.age);
         
    
    }
}
