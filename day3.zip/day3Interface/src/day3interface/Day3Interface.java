/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package day3interface;

/**
 *
 * @author macstudent
 */
public class Day3Interface {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Addition op1 = new Addition();
        //op1.display();
        counting obj2 = new counting();
        //obj2.display();
    
   // A obj3 = new A();
    //obj3.display();
   // obj3.calcMultiplication();
    
    
    B obj4 = new B();
    obj4.display();
    obj4.calcDivision();
    obj4.calcMultiplication();
    
    C obj5 = new C();
            obj5.calcDivision();
            obj5.display();
    }
    
}
interface Arithmetic{
    int n1 = 60;
    int n2 = 10;
    void display();
    }
class Addition implements Arithmetic{
//int n1 = 20;
//int n2 = 30;
    @Override
    public void display() {
       //System.out.println(n1 + " + " + n2 + " = "+ (n1+n2));
       System.out.println("Inside addition class");
    }
   
    
    
}
class counting extends Addition
{
    
}

interface multiplication extends Arithmetic{
    void calcMultiplication();
}
class A implements multiplication{
    public void display(){
        System.out.println(" n1 " + n1+ " n2 " + n2);
    }

    @Override
    public void calcMultiplication() {
        System.out.println((n1*n2));
    }
}

interface division extends Arithmetic{
    void calcDivision();
    
}
class B extends Addition implements division,multiplication{

    @Override
    public void calcDivision() {
      System.out.println(" Divison " + (n1/n2));
    }

    @Override
    public void display() {
        System.out.println("Inside b");
        System.out.println(" n1 = "+ n1 + " n2 = " + n2);
    }

    @Override
    public void calcMultiplication() {
       System.out.println("n1 * n2 "+ (n1*n2));
    }
    
}
class C extends B{
    int c1 = 20;
}